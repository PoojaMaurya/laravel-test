<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\frontend\CustomAuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('frontend/index');
});

//user login page url
Route::get('/login',[CustomAuthController::class, 'user_login'])->middleware('alreadyLoggedIn');
//user login post data
Route::post('/login-user',[CustomAuthController::class, 'loginUser'])->name('login-user');

//user registration page url
Route::get('/register', [CustomAuthController::class, 'new_user']);
//user registration post data
Route::post('/register-user',[CustomAuthController::class, 'registerUser'])->name('register-user');

//user dashboard page
Route::get('/dashboard',[CustomAuthController::class, 'dashboard'])->middleware('isLoggedIn');


//user logout page
Route::get('/logout',[CustomAuthController::class, 'logout']);



