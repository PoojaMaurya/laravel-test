<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Hash;
use Session;

class CustomAuthController extends Controller
{
    //user login
    public function user_login(){
        return view('frontend.login');
    }

    //user registration page
    public function new_user(){
        return view('frontend.register');
    }
    // post registration form data
    public function registerUser(Request $request){
        $request->validate([
            'name'=>'required',
            'email'=>'required|email|unique:users',
            'password'=>'required|min:5|max:8'
        ]);
        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $res = $user->save();
        if($res){
            return back()->with('success', 'User has been created successfuly');
        }
        else{
            return back()->with('fail', 'Fail to create user');
        }
    }
    // end post registration form data

    // post user login form data
    public function loginUser(Request $request){
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|min:5|max:8'
        ]);
        $user = User::where('email', '=',$request->email)->first();
        //user email and password check
        if($user){
            //user password check
            if(Hash::check($request->password, $user->password)){
                $request->session()->put('loginId', $user->id);
                return redirect('dashboard');
            }
            else{
                return back()->with('fail', 'The password you have provided, not matched');
            }
            //end user password check
        }
        else{
            return back()->with('fail', 'The email is not registered with us');
        }
    }
    //end user email and password check

    // show user dashboard
    public function dashboard(){
        $data = array();
        if(Session::has('loginId')){
            $data = User::where('id', '=',Session::get('loginId'))->first(); 
        }
       return view('frontend.user-dashboard', compact('data'));
      //return "welcome";
    }
     //end user dashboard

      // logout user dashboard
      
      public function logout(){
        if(Session::has('loginId')){
            Session::pull('loginId');
        }
        return view('frontend.login');
    }
     //end logout user dashboard
    
}
