<section id="cta" class="bg-fixed overlay" style="background-image: url(img/bg.jpg);">
    <div class="container">
        <div class="section-content" data-aos="fade-up">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="mb-2">Make a beautiful website, or million of them</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, veritatis qui eligendi delectus quia fuga!</p>
                    <a class="btn btn-outline-primary btn-lg">FEATURES</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of Features Section-->	
<footer class="mastfoot my-3">
    <div class="inner container">
         <div class="row">
         	<div class="col-lg-4 col-md-12 d-flex align-items-center">
         		
         	</div>
           
            <div class="col-lg-4 col-md-12">
            	<nav class="nav nav-mastfoot justify-content-center">
	                <a class="nav-link" href="#">
	                	<i class="fab fa-facebook-f"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-twitter"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-instagram"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-linkedin"></i>
	                </a>
	                <a class="nav-link" href="#">
	                	<i class="fab fa-youtube"></i>
	                </a>
	            </nav>
            </div>
            
        </div>
    </div>
</footer>	<!-- External JS -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
	<script src="{{url('frontend/vendor/bootstrap/popper.min.js')}}"></script>
	<script src="{{url('frontend/vendor/bootstrap/bootstrap.min.js')}}"></script>
	<script src="{{url('frontend/vendor/select2/select2.min.js')}} "></script>
	<script src="{{url('frontend/vendor/owlcarousel/owl.carousel.min.js')}}"></script>
	<script src="{{url('frontend/vendor/stellar/jquery.stellar.js')}}" type="text/javascript" charset="utf-8"></script>
	<script src="{{url('frontend/vendor/isotope/isotope.min.js')}}"></script>
	<script src="{{url('frontend/vendor/lightcase/lightcase.js')}}"></script>
	<script src="{{url('frontend/vendor/waypoints/waypoint.min.js')}}"></script>
	 <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
	 
	<!-- Main JS -->
	<script src="{{url('frontend/js/app.min.js')}}"></script>
	<script src="//localhost:35729/livereload.js"></script>
</body>
</html>