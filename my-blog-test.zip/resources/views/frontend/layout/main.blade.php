@include('frontend/layout/header')
@yield('main-section')
@include('frontend/layout/footer')