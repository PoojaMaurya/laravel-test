@extends('frontend.layout.main')

@section('main-section')	
<div class="jumbotron jumbotron-single d-flex align-items-center" style="background-image: url({{url('frontend/img/bg.jpg')}})">
  <div class="container text-center">
    <h1 class="display-2 mb-4">New User</h1>
  </div>
</div>		<!-- Contact Form Section -->
<section id="contact-form" class="bg-white">
    <div class="container">
        <div class="section-content">
            <!-- Section Title -->
            <div class="title-wrap" data-aos="fade-up">
                <h2 class="section-title">Please create an account</h2>
                <p class="section-sub-title">Praesent commodo cursus magna, vel scelerisque nisl consectetur et. <br> pharetra augue. Donec id elit non mi.</p>
            </div>
            <!-- End of Section Title -->
            <div class="row">
                <!-- Contact Form Holder -->
                <div class="col-md-8 offset-md-2 contact-form-holder mt-4" data-aos="fade-up">
                    <form method="post" name="user-register" action="/register-user">
                        @if(Session::has('success'))
                        <div class="alert alert-success">{{Session::get('success')}}</div>
                        @endif
                        @if(Session::has('fail'))
                        <div class="alert alert-danger">{{Session::get('fail')}}</div>
                        @endif
                        @csrf
                        <div class="row">
                            <div class="col-md-12 form-group">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="{{old('name')}}">
                                <span class="text-danger">
                                    @error('name') {{$message}} @enderror
                                </span>
                            </div>
                            <div class="col-md-6 form-group">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="{{old('email')}}">
                                <span class="text-danger">
                                    @error('email') {{$message}} @enderror
                                </span>
                            </div>
                            <div class="col-md-6 form-group">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="{{old('password')}}">
                                <span class="text-danger">
                                    @error('password') {{$message}} @enderror
                                </span>
                            </div>
                                               
                            <div class="col-md-12 text-center">
                                <button class="btn btn-primary btn-shadow btn-lg" type="submit" name="submit">Create</button>
                            </div>
                            <div class="custlink col-md-12"><span class="text-black">If already registered then</span>
                            <a class="login-link" href="/login">login here.</a>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- End of Contact Form Holder -->
            </div>
        </div>
        
    </div>
</section>
<!-- End of Contact Form Section -->		
<!-- Features Section-->

@endsection
